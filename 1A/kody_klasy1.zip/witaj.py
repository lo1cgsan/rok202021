#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  witaj.py
#  

print("Witaj!")
imie = input("Jak masz na imię? ")
print("Cześć", imie)
wiek = input("Ile masz lat? ")
print("Urodziłeś się w", 2020 - int(wiek), "roku!")

